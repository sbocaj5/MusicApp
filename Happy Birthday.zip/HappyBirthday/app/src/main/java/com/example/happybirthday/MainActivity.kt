package com.example.happybirthday

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.SoundPool
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var mediaPlayer : MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val atone = findViewById<Button>(R.id.Atone)
        atone.setOnClickListener {
            playAudio(R.raw.piano_a_a_major)
        }
        val btone = findViewById<Button>(R.id.BTone)
        btone.setOnClickListener{
            playAudio(R.raw.piano_b_b_major)
        }

    }

    private fun playAudio(soundFile: Int)
    {
        mediaPlayer = MediaPlayer.create(applicationContext,soundFile)
        mediaPlayer.start()
        Toast.makeText(this,"MediaPlaying",Toast.LENGTH_SHORT).show()
    }
}